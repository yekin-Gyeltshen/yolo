import Tkinter 
from Tkinter import *


main_window = Tkinter.Tk()
main_window.title("Nge Charo")
main_window.geometry("1000x750")
main_window.configure(background="deep sky blue")


def register():


	name_detail= name.get()
	gender_detail= gender.get()
	DOB_detail= dob.get()
	Address_detail=dzongkhag.get()
	Phone_Number=number.get()
	email_detail=email.get()

	f = open("Database.txt","a")
	f.write("Name: "+name_detail+ "\n")
	f.write("Gender:"+gender_detail+ "\n")
	f.write("DOB: "+DOB_detail+ "\n")
	f.write("Dzongkhag:"+Address_detail+ "\n")
	f.write("Number:"+Phone_Number+ "\n")
	f.write("Email:"+email_detail+ "\n"+"\n"+"\n")
	f.close()

	entry1.delete(0,END)
	entry2.delete(0,END)
	entry3.delete(0,END)
	entry4.delete(0,END)
	entry5.delete(0,END)
	entry6.delete(0,END)
	

	Label(window1,text="Entered successfully!",font= ("calibri",20)).grid(row=15,column=2)



def insertclicked():
	global window1
	window1=Toplevel(main_window)
	window1.title("Registry form")
	window1.geometry("700x650")
	window1.configure(background="grey")
	title=Label(window1,text="Fill in the Details",bg="yellow",font=("calibri",30)).grid(row=0,column=2)
	Label(window1,text =" ",bg="grey").grid(row=1)

	global name, gender,dob, dzongkhag, number, email
	global entry1, entry2, entry3, entry4, entry5, entry6


	name = StringVar()
	gender=StringVar()
	dob=StringVar()
	dzongkhag=StringVar()
	number=StringVar()
	email=StringVar()


	l1=Label(window1,text="Name",bg="yellow",height=2,width=15).grid(row=2)
	entry1=Entry(window1,textvariable=name,font=("calibri",20))
	entry1.grid(row=2,column=2)
	Label(window1, text = " ",bg="grey").grid(row=3)

	l2=Label(window1,text="Gender",bg="yellow",height=2,width=15).grid(row=4)
	entry2=Entry(window1,textvariable=gender,font=("calibri",20))
	entry2.grid(row=4,column=2)
	Label(window1, text = " ",bg="grey").grid(row=5)

	l3=Label(window1,text="DOB",bg="yellow",height=2,width=15).grid(row=6)
	entry3=Entry(window1,textvariable=dob,font=("calibri",20))
	entry3.grid(row=6,column=2)
	Label(window1, text = " ",bg="grey").grid(row=7)

	l4=Label(window1,text="Dzongkhag",bg="yellow",height=2,width=15).grid(row=8)
	entry4=Entry(window1,textvariable=dzongkhag,font=("calibri",20))
	entry4.grid(row=8,column=2)
	Label(window1, text = " ",bg="grey").grid(row=9)

	l5=Label(window1,text="Number",bg="yellow",height=2,width=15).grid(row=10)
	entry5=Entry(window1,textvariable=number,font=("calibri",20))
	entry5.grid(row=10,column=2)
	Label(window1, text = " ",bg="grey").grid(row=11)

	l6=Label(window1,text="Email",bg="yellow",height=2,width=15).grid(row=12)
	entry6=Entry(window1,textvariable=email,font=("calibri",20))
	entry6.grid(row=12,column=2)
	Label(window1, text = " ",bg="grey").grid(row=13)

	Label(window1, text = " ",fg="orange").grid(row=14)
	Button(window1, text = "Enter",bg="purple", width = 10, height = 1, command = register).grid(row=14,column=2)
	bt=Button(window1,text="<<Back",width=10, height=1,command=quit).grid(row=0)

def Graph():
	import matplotlib.pyplot as p
	global window3
	window3=Toplevel()
	window3.title("Graph")
	window3.geometry("700x650")

	Label(window3,text= "Number of male and female friends",font= ("calibri",20),bg="green").pack()
	with open("Database.txt","r") as f:
		f.seek(0)
		x=f.read()
		count1=x.count("male")
		count2=x.count("female")
	gender = ["male","female"]
	values = [count1,count2]
	p.title("number of male and female pie graph")
	p.pie(values,labels=gender,autopct='%1.1f%%',shadow=True)
	Label(window3,text="Number of male: ",font=("calibri",20,"bold")).pack()
	Label(window3, text=count1).pack()
	Label(window3,text="Number of female: ", font=("calibri",20,"bold")).pack()
	Label(window3,text = count2).pack()
	Label(window3,text=p.show()).pack()	


def Total():
	global window4
	window4 = Toplevel()
	window4.title("Total Friends")
	window4.geometry("700x650")

	Label(window4,text="number of Friends", font=("calibri",20,"bold")).pack()
	Label(window4,text=" ").pack()

	Label(window4,text="Total",font=("calibri")).pack()
	with open("Database.txt","a") as f:
		contents = f.read()
		count = contents.count("Name")
	Label(window4,text=count).pack()
	Label(window4,text=" ").pack()	


def display():

	global window2
	window2=Toplevel(main_window)
	window2.title("Nge Charo")
	window2.geometry("700x650")
	window2.configure(background="violet")

	Label(window2,text="Select to view details",bg="yellow",font=("calibri",20,"bold")).grid(row=1,column=2,sticky="E")
	Label(window2,text=" ",bg="violet").grid(row=3)
	Button(window2,text="Total Number of Friends",bg="orange",height=2,width=20,command=Total).grid(row=6,column=1,sticky="E")

	Button(window2,text="Graph",bg="orange",height=2,width= 20,command=Graph).grid(row=6,column=3,sticky="E")

def Search():
	global window5
	window5 = Toplevel(main_window)
	window5.title("Search FRiend")
	window5.geometry("700x650")
	window5.configure(background="dark blue")
	global search_var,search_entry	
	search_var = StringVar()

	Label(window5,text= "Enter your friend's name to search",).pack()
	Label(window5,text="Search",bg="yellow",font=("calibri",15,"bold")).pack()
	search_entry = Entry(window5,textvariable=search_var,font=("calibri",20))
	search_entry.pack()

	Label(window5,text=" ",bg="dark blue").pack()
	Button(window5,text="search",width=10,height=1,command=search).pack()




def search():
	search_info=search_var.get()
	f=open("Database.txt","r")
	ff=f.read()

	if search_info in ff:
		x="This name is registered"
		Label(window5,text=x).pack()
	else:
		y="no match"
		Label(window5,txt=y).pack()
	


def Delete():
	global window6
	window6 = Toplevel(main_window)
	window6.title("Delete function")
	window6.geometry("700x650")
	window6.configure(background="violet")

	global name_var,name_entry
	name_var = StringVar

	Label(window6,text="Enter the name to be removed").pack()
	Label(text="",bg="violet").pack()
	Label(text="",bg="violet").pack()
	name_entry=Entry(window6,textvariable=name_var)
	name_entry.pack()

	Label(window6,text=" ",bg="violet").pack()
	Button(window6,text="Delete",command=delete).pack()

def delete():
	import os
	search_info = name_var.get()
	f = open("Database.txt","r")
	ff = f.read()

	if search_info in ff:
		os.remove("name_var")
		x="The name you have entered has been deleted"
		Label(window6,text=x).pack()

	else:
		y="No Match"
		Label(window6,text=y).pack()


def main():
	 
	Label(text="Nge Charo",height=1,width=1000, fg="black",bg="yellow",font=("calibri",50)).pack()
	Label(text="",bg="sky blue").pack()
	Label(text="",bg="deep sky blue").pack()

	Button(text="Insert",height= 2,width=30,bg="blue",command = insertclicked,font=("calibri",15)).pack()
	Label(text="",bg="deep sky blue").pack()
	Button(text="Display",height=2,width=30,bg="blue",command = display,font=("calibri",15)).pack()
	Label(text="",bg="deep sky blue").pack()
	Button(text="Search",height=2,width=30,bg="blue",command = Search,font=("calibri",15)).pack()
	Label(text="",bg="sky blue").pack()
	Button(text="Delete",height=2,width=30,bg="red",font=("calibri",15),command=Delete).pack()	
	Label(text="",bg="deep sky blue").pack()
	Label(text="",bg="deep sky blue").pack()
	Label(text="",bg="deep sky blue").pack()
	Label(text="",bg="deep sky blue").pack()
	Button(main_window,text="EXIT",height=2,width=10,command=quit).pack()






	main_window.mainloop()
main()